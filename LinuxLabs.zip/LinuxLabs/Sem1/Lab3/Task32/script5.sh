#!/bin/bash
ls script* | sort
