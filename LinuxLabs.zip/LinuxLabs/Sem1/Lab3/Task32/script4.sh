#!/bin/bash
awk 'NR==1 {print $3}' ~/LinuxLabs/Sem1/Lab3/Task32/basa.txt
