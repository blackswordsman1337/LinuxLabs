#!/bin/bash
ls *_* | sort

