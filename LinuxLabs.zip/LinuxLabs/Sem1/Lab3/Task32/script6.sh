#!/bin/bash
tr -cd '[:alpha:]' < ~/LinuxLabs/Sem1/Lab3/Task32/basa.txt
