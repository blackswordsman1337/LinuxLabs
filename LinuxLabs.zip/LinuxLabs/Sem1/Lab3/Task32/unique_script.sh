#!/bin/bash
cat ~/LinuxLabs/Sem1/Lab3/Task32/basa.txt ~/LinuxLabs/Sem1/Lab3/Task32/n_basa.txt | sort | uniq > ~/LinuxLabs/Sem1/Lab3/Task32/un_basa.txt
