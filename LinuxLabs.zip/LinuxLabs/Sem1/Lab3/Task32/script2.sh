#!/bin/bash
touch ~/LinuxLabs/Sem1/Lab3/Task32/t11.txt
sort ~/LinuxLabs/Sem1/Lab3/Task32/basa.txt > ~/LinuxLabs/Sem1/Lab3/Task32/t11.txt
cat ~/LinuxLabs/Sem1/Lab3/Task32/t11.txt > ~/LinuxLabs/Sem1/Lab3/Task32/basa.txt
