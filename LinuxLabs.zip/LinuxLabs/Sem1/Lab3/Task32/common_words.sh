#!/bin/bash
sort basa.txt > s1.txt
sort basa2.txt > s2.txt
echo "$(comm -12 s1.txt s2.txt | wc -w)"
rm s1.txt s2.txt
