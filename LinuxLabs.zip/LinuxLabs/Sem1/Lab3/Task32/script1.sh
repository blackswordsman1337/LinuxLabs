#!/bin/bash
sed 's/Nutrina/Stankewich/' ~/LinuxLabs/Sem1/Lab3/Task32/basa.txt > ~/LinuxLabs/Sem1/Lab3/Task32/n_basa.txt
