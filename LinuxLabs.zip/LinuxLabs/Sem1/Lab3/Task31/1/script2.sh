#!/bin/bash
find ~/LinuxLabs/Sem1/Lab3/Task31/1 -type f -name "script*" > ~/LinuxLabs/Sem1/Lab3/Task31/1/list.txt
