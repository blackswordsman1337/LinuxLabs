#!/bin/bash
if [ -f ~/LinuxLabs/Sem1/Lab3/Task31/1/script1.sh ]; then
	bash ~/LinuxLabs/Sem1/Lab3/Task31/1/script1.sh
fi
