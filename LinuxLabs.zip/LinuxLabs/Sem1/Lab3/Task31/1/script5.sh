#!/bin/bash
for interperor in /bin/bash /bin/zsh /usr/local/bin/fish; do
	if [ -f "$interperor" ]; then
		echo "interperor: $interperor"
	fi
done
echo "current: $SHELL" 
