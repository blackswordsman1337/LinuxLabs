#!/bin/bash
cat ~/LinuxLabs/Sem1/Lab3/Task31/1/file2.txt > ~/LinuxLabs/Sem1/Lab3/Task31/1/file1.txt
