#!/bin/bash
cp ~/LinuxLabs/Sem1/Lab3/Task31/1/file1.txt ~/LinuxLabs/Sem1/Lab3/Task31/1/file2.txt
