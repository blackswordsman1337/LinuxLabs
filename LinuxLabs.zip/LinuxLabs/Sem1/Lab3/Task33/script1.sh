#!/bin/bash
echo "script1"
