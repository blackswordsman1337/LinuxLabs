#!/bin/bash
bash ~/LinuxLabs/Sem1/Lab3/Task33/script1.sh
