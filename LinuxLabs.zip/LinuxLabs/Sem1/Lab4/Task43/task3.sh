#!/bin/bash

report_home_space () {
    local format="%-15s%-15s%-15s\n"
    local i dir_list total_files total_dirs total_size user_name

    if [[ $(id -u) -eq 0 ]]; then
        dir_list="/home/*"
        user_name="All Users"
    else
        dir_list="$HOME"
        user_name="$USER"
    fi

    echo "Home Space Utilization ($user_name)"

    for i in $dir_list; do
        total_files=$(find "$i" -type f | wc -l)
        total_dirs=$(find "$i" -type d | wc -l)
        total_size=$(du -sh "$i" | cut -f 1)

        zenity --text-info --width=400 --height 200 --title="Report Home Space" --filename=/dev/stdin <<EOF
$i
$(printf "$format" "Dirs" "Files" "Size")
$(printf "$format" "----" "-----" "----")
$(printf "$format" "$total_dirs" "$total_files" "$total_size")
EOF
    done
}

report_home_space
