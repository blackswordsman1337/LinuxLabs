#!/bin/bash

gdialog --title "Select" --yesno "Are you a man?" 9 18
case "$?" in
    *) gdialog title "Select" --yesno "Are you sure?" 5, 20;;

    esac
    sleep 1
    exit 0
