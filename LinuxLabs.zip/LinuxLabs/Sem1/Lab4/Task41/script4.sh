#!/bin/bash

currencies=("USD" "EUR" "KZT")

choice=$(zenity --list --title "Выберите валюту" --column "Валюта" "${currencies[@]}" "Выход")

case $choice in
    "USD") zenity --info --title "Котировка USD" --text "Котировка USD: 3,29 BYN";;
    "EUR") zenity --info --title "Котировка EUR" --text "Котировка EUR: 3,45 BYN";;
    "KZT") zenity --info --title "Котировка KZT" --text "Котировка KZT: 0,0069 BYN";;
    "Выход") exit 0;;
    *) zenity --error --title "Ошибка" --text "Выбранной валюты нет в списке.";;
esac
