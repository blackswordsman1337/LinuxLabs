#!/bin/bash

currencies=("USD" "EUR" "KZT")

while true; do
    choice=$(zenity --list --column="Валюта" "${currencies[@]}" "Выход")
    
    case $choice in
        "Выход") exit 0;;
        "USD") zenity --info --title "Котировка USD" --text "Котировка USD: 3,29 BYN";;
    	"EUR") zenity --info --title "Котировка EUR" --text "Котировка EUR: 3,45 BYN";;
    	"KZT") zenity --info --title "Котировка KZT" --text "Котировка KZT: 0,0069 BYN";;
    esac
done
