#!/bin/bash

name=$(zenity --entry --title "Type your name" --text "Your name:")
profession=$(zenity --entry --title "Type your profession" --text "Your profesion:")

zenity --info --title "Result" --text "Name: $name\nProfession: $profession"

exit 0
